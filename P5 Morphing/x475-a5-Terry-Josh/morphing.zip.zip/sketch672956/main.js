/* morph between two images */
/* define all global variables */
let width, height; // image dimensions, have to match in this version
let leftSource, rightSource; // two source panes
let target; // one target pane
let theta = 0.0; // time=0.5-cos(theta)/2.0;
let image1, image2;
let leftVertices, rightVertices, faces;

function preload(){
	image1 = loadImage("img0.png");
	image2 = loadImage("img1.png");
	leftVertices = loadStrings("left-vertices.txt");
	rightVertices = loadStrings("right-vertices.txt");
	faces = loadStrings("faces.txt");
}

/* setup required variables, this function runs only once */
function setup() {
    /* create the display */
    width = image1.width;
    height = image1.height;
    createCanvas(width*3, height); // allocate space for 3 images

    /* create three panes */
    leftSource = new Source(0, 0, image1);
    leftSource.loadData(leftVertices,faces);

    rightSource = new Source(2 * width, 0, image2);
    rightSource.loadData(rightVertices,faces);

    target = new Target(width, 0);
		
		/* run test cases */
		// verifyInterpolateTriangle();
		// verifyFromTriangles();
		// verifyGetPixelColor();
		// verifyGetBlendedColor();
}

/* executed like an infinite loop, each frame is rendered here */
function draw() {
	const showInnards = false; // display/hide the triangles
  /* calculate time */
	const time = 0.5 - Math.cos(theta) / 2.0;
	theta += 0.05;
	/* diplay left, right and target pane */
	leftSource.paintImage();
  rightSource.paintImage();
	/* createsMorph changes the target image over time */
  target.createMorph(time);
  target.paintImage();
	/* display triangles if the flag is set */
    if (showInnards) {
        leftSource.drawTriangles();
        rightSource.drawTriangles();
        target.paintTriangles();
    }
}