/**
 * a Pane keeps an image and a list of triangles
 * and is situated at coordinate x0,y0 in the display
 */
class Pane {
    /** create a Pane */
    constructor(x, y, image) {
        this.x0 = x;
        this.y0 = y;
        this.width = image.width;
        this.height = image.height;
        this.image = image;
        this.numberOfTriangles = 0;
        this.triangles = [];

    }
    /** loads the given stringLists as vertices and faces */
    loadData(vertexList, triangleList) {
        const vertices = [];
        this.triangles.length = 0;
        /** remove empty items from list */
        vertexList = vertexList.filter(item => item)
        triangleList = triangleList.filter(item => item)
        /** update lengths of lists */
        this.numberOfTriangles = triangleList.length;
				/** fill in all vertices */
        for (let i = 0; i < vertexList.length; i++) {
            const points = vertexList[i].split(" ");
            vertices[i] = new Point2D(parseFloat(points[0]), parseFloat(points[1]));
        }
				/** fill in all triangles */
        for (let i = 0; i < triangleList.length; i++) {
            const points = triangleList[i].split(" ");
            this.triangles[i] = new Triangle(
                vertices[parseInt(points[0])],
                vertices[parseInt(points[1])],
                vertices[parseInt(points[2])]);
        }
    }

    /**
     * async function that loads the text files as strings
     * and calls loadDate with the stringLists
     */
    loadTriangles(verticesFilename, TrianglesFilename) {
        loadStrings(verticesFilename, (vertexList) => {
            loadStrings(TrianglesFilename, (triangleList) => {
                this.loadData(vertexList, triangleList);
            });
        });
    }

    /* paint the image */
    paintImage() {
        image(this.image, this.x0, this.y0);
    }

    /* paint all triangles in funky colors, blue channel is index t */
    paintTriangles() {
        noStroke();
        for (let t = 0; t < this.numberOfTriangles; t++) {
            const g = parseInt(256 * parseFloat(t) / parseFloat(this.numberOfTriangles));
            fill(g, 255 - g, t);
            this.triangles[t].stroke(this.x0, this.y0);
        }
    }

    /* draw all triangles */
    drawTriangles() {
        stroke(0);
        noFill();
        for (let t = 0; t < this.numberOfTriangles; t++) {
            this.triangles[t].stroke(this.x0, this.y0);
        }
    }
}