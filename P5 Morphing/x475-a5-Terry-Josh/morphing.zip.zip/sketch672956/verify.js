function verifyInterpolateTriangle() {
	
		triangleA = new Triangle(new Point2D(0, 0), new Point2D(2, 0), new Point2D(0, 2));
		triangleB = new Triangle(new Point2D(0, 0), new Point2D(8, 0), new Point2D(0, 4));
	
		let tests = [
			{
				message: "Testing interpolateTriangle()",
				subtests: [
					{ 
						condition: isEqual(TriangleFactory.interpolateTriangle(triangleA, triangleB, 0), triangleA),
						errorMsg: "At time = 0 the output should be equal to the first input argument"
					},
					{ 
						condition: isEqual(TriangleFactory.interpolateTriangle(triangleA, triangleB, 1), triangleB),
						errorMsg: "At time = 1 the output should be equal to the second input argument"
					},
					{ 
						condition: isEqual(TriangleFactory.interpolateTriangle(triangleA, triangleB, 0.5), new Triangle(new Point2D(0, 0), new Point2D(5, 0), new Point2D(0, 3))),
						errorMsg: "At time = 0.5 the output triangle's vertices should be exactly halfway between the first and second input triangle's vertices"
					}
				]
			}
		];

	// run tests
	runTests(tests);
}

function verifyFromTriangles() {

		triangleA = new Triangle(new Point2D(0, 0), new Point2D(8, 0), new Point2D(0, 4));
		triangleB = new Triangle(new Point2D(0, 0), new Point2D(2, 0), new Point2D(0, 2));
		triangleC = new Triangle(new Point2D(0, 0), new Point2D(0, -8), new Point2D(4, 0));
	
		classExampleDestination = new Triangle(new Point2D(0, 0), new Point2D(1, 0), new Point2D(0, 1));
		classExampleSource = new Triangle(new Point2D(7, 5), new Point2D(10, 8), new Point2D(6, 9));
	
	let tests = [
		{
			message: "Testing fromTriangles()",
			subtests: [
				{ 
					condition: isEqual(AffineFactory.fromTriangles(triangleA, triangleB), new Affine(4, 0, 0, 0, 2, 0)),
					errorMsg: "A scaling transformation of factor s in the x dimension and factor k in the y dimension should output [s 0 0, 0 k 0]"
				},
				{ 
					condition: isEqual(AffineFactory.fromTriangles(triangleA, triangleA), new Affine(1, 0, 0, 0, 1, 0)),
					errorMsg: "The affine transform matrix between a triangle and itself should be [1 0 0, 0 1 0]"
				},
				{ 
					condition: isEqual(AffineFactory.fromTriangles(triangleA, triangleC), new Affine(0, -1, 0, 1, 0, 0)),
					errorMsg: "A 90 degrees rotation should output [0 -1 0, 1 0 0]"
				},
				{ 
					condition: isEqual(AffineFactory.fromTriangles(classExampleSource, classExampleDestination), new Affine(3, -1, 7, 3, 4, 5)),
					errorMsg: "The example given in class and repeated in the assignment did not yield the desired result"
				}
			]
		}
	];

	// run tests
	runTests(tests);
}

function verifyGetPixelColor() {
	
	// create 4 by 3 source for testing
	targetVerify = new Target(0, 0);
	 
	img = createImage(4, 3);
	img.loadPixels();
	
	for (let i = 0; i < 12; i++) {
		img.pixels[4*i] = i*10;
		img.pixels[4*i + 1] = i*10;
		img.pixels[4*i + 2] = i*10;
		img.pixels[4*i + 3] = 255;
	}
	img.updatePixels();
	
	source = new Source(0, 0, img);
	
	// create testing transformations
	t1 = new Affine(1, 0, 0, 0, 1, 0); // identity
	t2 = new Affine(3, 0, 0, 0, 2, 0); // scaling
	
	let tests = [
		{
			message: "Testing getPixelColor()",
			subtests: [
				{ 
					condition: isEqual(targetVerify.getPixelColor(new Point2D(2, 0),source,t1), [20, 20, 20, 255]),
					errorMsg: "An identity affine transformation should select the color of the input argument point from the source image"
				},
				{ 
					condition: isEqual(targetVerify.getPixelColor(new Point2D(1, 1),source,t2), [110, 110, 110, 255]),
					errorMsg: "Wrong color returned by getPixelColor"
				}
			]
		}
	];
	
	// run tests
	runTests(tests);
}

function verifyGetBlendedColor() {
	
	targetVerify = new Target(0, 0);

	let tests = [
		{
			message: "Testing getBlendedColor()",
			subtests: [
				{ 
					condition: isEqual(targetVerify.getBlendedColor(color(20, 20, 20),color(10, 10, 10), 0), color(20, 20, 20)),
					errorMsg: "At time = 0 the output should be equal to the first input argument"
				},
				{ 
					condition: isEqual(targetVerify.getBlendedColor(color(20, 20, 20),color(10, 10, 10), 1), color(10, 10, 10)),
					errorMsg: "At time = 1 the output should be equal to the second input argument"
				},
				{ 
					condition: isEqual(targetVerify.getBlendedColor(color(10, 10, 10),color(20, 20, 20), 0.5), color(15, 15, 15)),
					errorMsg: "At time = 0.5 the output should be exactly halfway between the first and second input arguments"
				}
			]
		}
	];

	// run tests
	runTests(tests);
}

function runTests(tests) {

	// run tests
	tests.forEach(test => {

		// print test message
		println(test.message.toUpperCase());
		println(" ");

		// run subtests for this test
		let failed = 0; // number of subtests failed
		
		for(let i = 0; i < test.subtests.length; i++) {

			let subtest = test.subtests[i];

			if(subtest.condition) {
				println("Check " + (i+1) + " passed");
			} else {
				failed++;
				println("Check " + (i+1) + " failed: " + subtest.errorMsg);
			}
		}
		println(" ");

		// all subtests passed
		if(failed === 0) {
			println("All checks passed.");
		} else {
			println(failed + " out of " + test.subtests.length + " checks failed.");
		}
		
		println("______________________________________________");
  		
	});
}

// utility function to check if two arrays are equal
function isEqual(a, b) {
	return objectHash.sha1(a) === objectHash.sha1(b);
	// use Lodash to comapre arrays
    //return _.isEqual(a, b);
}