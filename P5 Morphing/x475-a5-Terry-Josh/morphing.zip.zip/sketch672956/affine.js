class Affine {
	/* updates affine values with given value */
	constructor(a, b, c, d, e, f) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.e = e;
		this.f = f;
	}
	
	/* point2D p */
	transform(p) {
		return new Point2D(
			this.a * p.x + this.b * p.y + this.c,
			this.d * p.x + this.e * p.y + this.f);
	}

	print() {
		console.log("Affine:");
		console.log(this.a + "\t" + this.b + "\t" + this.c);
		console.log(this.d + "\t" + this.e + "\t" + this.f);
	}
}

/**
 * contains helper methods that return Affine Object
 */
class AffineFactory {
	static fromTriangles(sourceTriangle, destinationTriangle){
		
		var srcPoints = [sourceTriangle.t1.x, sourceTriangle.t1.y,
										 sourceTriangle.t2.x, sourceTriangle.t2.y,
										 sourceTriangle.t3.x, sourceTriangle.t3.y];
		var dstPoints = [destinationTriangle.t1.x, destinationTriangle.t1.y,
										 destinationTriangle.t2.x, destinationTriangle.t2.y,
										 destinationTriangle.t3.x, destinationTriangle.t3.y];
		
		let srcMatrix = cv.matFromArray(3, 1, cv.CV_32FC2, srcPoints)
		let dstMatrix = cv.matFromArray(3, 1, cv.CV_32FC2, dstPoints)
		let affMatrix = cv.getAffineTransform(dstMatrix,srcMatrix)
		
		var a =	affMatrix.doubleAt(0,0);
		var b =	affMatrix.doubleAt(0,1);
		var c =	affMatrix.doubleAt(0,2);
		var d =	affMatrix.doubleAt(1,0);
		var e =	affMatrix.doubleAt(1,1);
		var f =	affMatrix.doubleAt(1,2);
		
		const result = new Affine(a, b, c, d, e, f);
		return result;
	}
}