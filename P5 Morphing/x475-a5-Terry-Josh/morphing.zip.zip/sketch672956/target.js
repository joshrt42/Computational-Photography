/**
 * a target is a Pane that morphs two images
 */
class Target extends Pane {
    constructor(x, y) {
        /* little hack: leftSource and rightSource are globally accessible */
        super(x, y, createImage(leftSource.image.width, rightSource.image.height));
    }
		
		getPixelColor(p,source,destToSource){

			var x = parseInt(destToSource.transform(p).x);
			var y = parseInt(destToSource.transform(p).y);
			
			const result = source.image.get(x,y);
			return result;
		}
		
		getBlendedColor(leftColor,rightColor,time){

			const r = red(leftColor)*(1-time) + red(rightColor)*time;
			const g = green(leftColor)*(1-time) + green(rightColor)*time;
			const b = blue(leftColor)*(1-time) + blue(rightColor)*time;
			const result = color(r,g,b);
			return result;
		}
		
		
    /* blend the two sources */
    createMorph(time) {
        /* step1: Compute blended triangles */
        this.numberOfTriangles = leftSource.numberOfTriangles;
        this.triangles = [];
        for (let i = 0; i < this.numberOfTriangles; i++) {
            this.triangles[i] = TriangleFactory.interpolateTriangle(leftSource.triangles[i], rightSource.triangles[i], time);
        }

        /*
         * step 2: Calculate affine transformation parameters
         * **************************************************
         * CALCULATE AFFINE TRANSFORMS HERE
         */
        const A1 = [];
        const A2 = [];
        for (let i = 0; i < this.numberOfTriangles; i++) {
            A1[i] = AffineFactory.fromTriangles(leftSource.triangles[i], this.triangles[i]);
            A2[i] = AffineFactory.fromTriangles(rightSource.triangles[i], this.triangles[i]);
        }

        /*
         * step 3: paint the triangles
         * major trick: puts the correct triangle in blue channel!
         */
        this.paintTriangles();

        /* step 4: loop over target pixels to create blended image */
        loadPixels();
        this.image.loadPixels();
        leftSource.image.loadPixels();
        rightSource.image.loadPixels();

				/* iterate through the target image */
        for (let u = 0; u < this.width; u++) {
            for (let v = 0; v < this.height; v++) {
								/* retrieve index of the triangle from blue channel */
								const index = parseInt(blue(get(this.x0+u,this.y0+v)));
								/* skip if index out of range */
								if (index<0 || index>=this.numberOfTriangles) continue;
								const p = new Point2D(u,v);
								/* get colors of corresponding pixels in leftSource and rightSource given p */ 
								const c1 = this.getPixelColor(p,leftSource,A1[index]);
								const c2 = this.getPixelColor(p,rightSource,A2[index]);
								/* update the color of the pixel at position u,v */
								const newColor = this.getBlendedColor(c1,c2,time);
								this.image.set(u,v,newColor);
            }
        }
				/* load updated pixels */
        this.image.updatePixels();
    }
}