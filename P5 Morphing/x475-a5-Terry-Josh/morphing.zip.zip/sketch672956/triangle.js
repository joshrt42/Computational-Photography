/**
 * used to represent a triangle using 3 Point2D objects
 */
class Triangle {
		/* sets the 3 points required to represent a triangle */
    constructor(t1, t2, t3) {
        this.t1 = t1;
        this.t2 = t2;
        this.t3 = t3;
    }

		/* paints the triangle on canvas */
    stroke(x0, y0) {
        const x1 = x0 + parseInt(this.t1.x);
        const y1 = y0 + parseInt(this.t1.y);
        const x2 = x0 + parseInt(this.t2.x);
        const y2 = y0 + parseInt(this.t2.y);
        const x3 = x0 + parseInt(this.t3.x);
        const y3 = y0 + parseInt(this.t3.y);
        triangle(x1, y1, x2, y2, x3, y3);
    }

    print() {
        console.log("Triangle:");
        console.log(
            "(" + this.t1.x + ", " + this.t1.y + ")  " +
            "(" + this.t2.x + ", " + this.t2.y + ")  " +
            "(" + this.t3.x + ", " + this.t3.y + ")  ");
    }
}

/**
 * factory has helper methods that return objects of type Triangle
 */
class TriangleFactory {
    static interpolateTriangle(triangle1, triangle2, time) {
			
			var p1 = new Point2D(triangle1.t1.x*(1-time) + triangle2.t1.x*time,
																triangle1.t1.y*(1-time) + triangle2.t1.y*time)
			var p2 = new Point2D(triangle1.t2.x*(1-time) + triangle2.t2.x*time,
																triangle1.t2.y*(1-time) + triangle2.t2.y*time)
			var p3 = new Point2D(triangle1.t3.x*(1-time) + triangle2.t3.x*time,
																triangle1.t3.y*(1-time) + triangle2.t3.y*time)
			const result = new Triangle(p1, p2, p3);
			return result;
    }
}