/**
 * Source is a Pane that allows pixel colors to be queried
 */
class Source extends Pane {
	constructor(x, y, img) {
		super(x, y, img);
		this.chosen = 0;
	}
}