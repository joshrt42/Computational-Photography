	let frameA = new p5.Image(4, 3);
	let frameB = new p5.Image(4, 3);
	let frameC = new p5.Image(4, 3);

	let pixelsA = [0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255];
	let pixelsB = [1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255, 1, 1, 1, 255];
	let pixelsC = [4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255, 4, 4, 4, 255];

	// create images with appropriate pixels
	frameA.loadPixels();
	frameA.pixels = pixelsA;
	frameA.updatePixels();

	frameB.loadPixels();
	frameB.pixels = pixelsB;
	frameB.updatePixels();

	frameC.loadPixels();
	frameC.pixels = pixelsC;
	frameC.updatePixels();

function verifySSD() {
	
	let tests = [{
		message: "Testing ssd()",
		subtests: [{
				condition: VideoTexture.ssd(frameA, frameA) === 0,
				errorMsg: "The sum of squared difference between an image and itself should be zero"
			},
			{
				condition: VideoTexture.ssd(frameA, frameB) === 12,
				errorMsg: "Incorrect output"
			},
			{
				condition: VideoTexture.ssd(frameB, frameC) === 108,
				errorMsg: "Incorrect output. If this test fails and the previous two pass, check that you are squaring the difference"
			},
			{
				condition: VideoTexture.ssd(frameC, frameA) === 192,
				errorMsg: "Incorrect output. If this test fails and the first two pass, check that you are squaring the difference"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyCalculateSumSquaredDistances() {

	let framesArrayA = [frameA, frameB, frameC];
	let framesArrayB = [frameB, frameA, frameC];
	let framesArrayC = [frameA, frameA, frameB];
	
	let ssdA = [[0, 12, 192], [12, 0, 108], [192, 108, 0]];
	let ssdB = [[0, 12, 108], [12, 0, 192], [108, 192, 0]];
	let ssdC = [[0, 0, 12], [0, 0, 12], [12, 12, 0]];
	
	let ssdMatA = new Matrix(3);
	let ssdMatB = new Matrix(3);
	let ssdMatC = new Matrix(3);
	
	ssdMatA.data = ssdA;
	ssdMatB.data = ssdB;
	ssdMatC.data = ssdC;
	
	let tests = [{
		message: "Testing calculateSumSquaredDistances()",
		subtests: [{
				condition: VideoTexture.calculateSumSquaredDistances(framesArrayA) instanceof Matrix,
				errorMsg: "Output type is incorrect, it should be an object of type Matrix"
			},
			{
				condition: VideoTexture.calculateSumSquaredDistances(framesArrayA).row(0)[0] === 0 && VideoTexture.calculateSumSquaredDistances(framesArrayA).row(1)[1] === 0 && VideoTexture.calculateSumSquaredDistances(framesArrayA).row(2)[2] === 0,
				errorMsg: "All values on the main diagonal of the ssd matrix should be equal to zero, but it's not"
			},
			{
				condition: isEqual(VideoTexture.calculateSumSquaredDistances(framesArrayA), ssdMatA),
				errorMsg: "Incorrect output"
			},
			{
				condition: isEqual(VideoTexture.calculateSumSquaredDistances(framesArrayB), ssdMatB),
				errorMsg: "Incorrect output"
			},
			{
				condition: isEqual(VideoTexture.calculateSumSquaredDistances(framesArrayC), ssdMatC),
				errorMsg: "Incorrect output"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyCalculateProbabilities() {
	
	let ssdA = [[1, 1, 1],[1, 1, 1],[1, 1, 1]];
	let ssdB = [[0, 0, 0],[0, 0, Math.log(4)/(3e-7)],[Math.log(9)/(3e-7), 0, 0]];
	let ssdC = [[0, 0, 0],[0, 0, Math.log(4)/(15e-8)],[Math.log(9)/(15e-8), 0, 0]];
	let ssdD = [[0, 0, 0],[1, 0, 1+Math.log(4)/(15e-8)],[1+Math.log(9)/(15e-8), 0, 1]];
	
	let ssdMatA = new Matrix(3);
	let ssdMatB = new Matrix(3);
	let ssdMatC = new Matrix(3);
	let ssdMatD = new Matrix(3);
	
	ssdMatA.data = ssdA;
	ssdMatB.data = ssdB;
	ssdMatC.data = ssdC;
	ssdMatD.data = ssdD;
	
	let probA = [[0, 0.5, 0.5], [0.5, 0, 0.5], [0.5, 0.5, 0]]
	let probB = [[0, 0.5, 0.5], [0.8, 0, 0.19999999999999996], [0.09999999999999998, 0.8999999999999999, 0]];
	let probC = [[0, 0.5, 0.5], [0.8, 0, 0.19999999999999996], [0.09999998650000079, 0.9000000134999991, 0]];
	
	let probMatA = new Matrix(3);
	let probMatB = new Matrix(3);
	let probMatC = new Matrix(3);
	
	probMatA.data = probA;
	probMatB.data = probB;
	probMatC.data = probC;
	
	let tests = [{
		message: "Testing calculateProbabilities()",
		subtests: [{
				condition: VideoTexture.calculateProbabilities(ssdMatA, 1) instanceof Matrix,
				errorMsg: "Output type is incorrect, it should be an object of type Matrix"
			},
			{
				condition: isEqual(VideoTexture.calculateProbabilities(ssdMatA, 1), probMatA),
				errorMsg: "Incorrect output. Check that you are normalizing the probabilities correctly and that values on the main diagonal are set to zero"
			},
			{
				condition: isEqual(VideoTexture.calculateProbabilities(ssdMatB, 0.5), probMatB),
				errorMsg: "Incorrect output."
			},
			{
				condition: isEqual(VideoTexture.calculateProbabilities(ssdMatC, 1), probMatB),
				errorMsg: "Incorrect output. If the previous test passes and this one fails check that you are dividing by 2*sigma correctly"
			},
			{
				condition: isEqual(VideoTexture.calculateProbabilities(ssdMatD, 1), probMatC),
				errorMsg: "Incorrect output. If the previous tests pass and this one fails check that you are subtracting minimum distance correctly"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyCalculateCumulativeProbabilities() {
	
	let probA = [[0, 0.1, 0.9], [0.2, 0.3, 0.5], [0.5, 0.1, 0.2]];
	let probB = [[0.95, 0.05, 0], [0.35, 0.55, 0.1], [0.3, 0.3, 0.4]];
	let probC = [[0.8, 0.15, 0.05], [0.3, 0.3, 0.4], [0.1, 0.1, 0.8]];
	
	let probMatA = new Matrix(3);
	let probMatB = new Matrix(3);
	let probMatC = new Matrix(3);
	
	probMatA.data = probA;
	probMatB.data = probB;
	probMatC.data = probC;
	
	let cProbA = [[0, 0.1, 1], [0.2, 0.5, 1], [0.5, 0.6, 0.8]];
	let cProbB = [[0.95, 1, 1], [0.35, 0.9, 1], [0.3, 0.6, 1]];
	let cProbC = [[0.8, 0.9500000000000001, 1], [0.3, 0.6, 1], [0.1, 0.2, 1]];
	
	let cProbMatA = new Matrix(3);
	let cProbMatB = new Matrix(3);
	let cProbMatC = new Matrix(3);
	
	cProbMatA.data = cProbA;
	cProbMatB.data = cProbB;
	cProbMatC.data = cProbC;
	
	let tests = [{
		message: "Testing calculateCumulativeProbabilities()",
		subtests: [{
				condition: VideoTexture.calculateCumulativeProbabilities(probMatA) instanceof Matrix,
				errorMsg: "Output type is incorrect, it should be an object of type Matrix"
			},{
				condition: isEqual(VideoTexture.calculateCumulativeProbabilities(probMatA), cProbMatA),
				errorMsg: "Incorrect output"
			},
							 {
				condition: isEqual(VideoTexture.calculateCumulativeProbabilities(probMatB), cProbMatB),
				errorMsg: "Incorrect output"
			},
							 {
				condition: isEqual(VideoTexture.calculateCumulativeProbabilities(probMatC), cProbMatC),
				errorMsg: "Incorrect output"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyMaxProbabilities() {
	
	let probA = [[0, 0.1, 0.9], [0.2, 0.3, 0.5], [0.5, 0.1, 0.2]];
	let probB = [[0.5, 0.5, 0], [0.3, 0.5, 0.1], [0.3, 0, 0.4]];
	let probC = [[0.8, 0.15, 0.05], [0.3, 0.3, 0.4], [0.1, 0.1, 0.8]];
	
	let probMatA = new Matrix(3);
	let probMatB = new Matrix(3);
	let probMatC = new Matrix(3);
	
	probMatA.data = probA;
	probMatB.data = probB;
	probMatC.data = probC;
	
	let tests = [{
		message: "Testing maxProbabilities()",
		subtests: [{
				condition: VideoTexture.maxProbabilities(probMatA) instanceof Array,
				errorMsg: "Output type is incorrect, it should be an array"
			},
			{
				condition: isEqual(VideoTexture.maxProbabilities(probMatA), [0.9, 0.5, 0.5]),
				errorMsg: "Incorrect output"
			},
			{
				condition: isEqual(VideoTexture.maxProbabilities(probMatB), [0.5, 0.5, 0.4]),
				errorMsg: "Incorrect output"
			},
			{
				condition: isEqual(VideoTexture.maxProbabilities(probMatC), [0.8, 0.4, 0.8]),
				errorMsg: "Incorrect output"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function runTests(tests) {

	// run tests
	tests.forEach(test => {

		// print test message
		println(test.message.toUpperCase());
		println(" ");

		// run subtests for this test
		let failed = 0; // number of subtests failed

		for (let i = 0; i < test.subtests.length; i++) {

			let subtest = test.subtests[i];

			if (subtest.condition) {
				println("Check " + (i + 1) + " passed");
			} else {
				failed++;
				println("Check " + (i + 1) + " failed: " + subtest.errorMsg);
			}
		}
		println(" ");

		// all subtests passed
		if (failed === 0) {
			println("All checks passed.");
		} else {
			println(failed + " out of " + test.subtests.length + " checks failed.");
		}

		println("______________________________________________");

	});
}

// utility function to check if two arrays / objects are equal
function isEqual(a, b) {
	return objectHash.sha1(a) === objectHash.sha1(b);
}
