/**
 * square row major matrix
 */
class Matrix {
	/* construct a matrix given the size 'n'*/
	constructor(n) {
		// mat.length returns the size of the square matrix
		this.length = n;
		this.data = new Array(n);
		for (let i = 0; i < n; i++) {
			this.data[i] = new Array(n);
		}
	}
	
	/* return ith row of the matrix */
	row(i){
		return this.data[i];
	}
}