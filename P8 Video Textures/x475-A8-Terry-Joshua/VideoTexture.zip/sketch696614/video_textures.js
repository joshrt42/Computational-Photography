class VideoTexture {
	/* calculate sum squared distance between green channel of two frames where frames are P5.js image and the return type is a number */
	static ssd(frameA, frameB) {
		frameA.loadPixels();
		frameB.loadPixels();
		let ssd = 0;
		for (let i = 0; i < frameA.height*frameA.width; i++) {
			let px1 = frameA.pixels[i*4 + 1];
			let px2 = frameB.pixels[i*4 + 1];
			let val = Math.pow(px1-px2, 2);
			ssd += val;
		}
		return ssd;
	}

	/* calculate SSD for all frames into a Matrix object */
	static calculateSumSquaredDistances(frames) {
		let ssd = new Matrix(frames.length);
		for (let i = 0; i < frames.length; i++) {
			for (let j = 0; j < i; j++) {
				if (i == j) {
					ssd.row(i)[j] = 0;
				} else {
					ssd.row(i)[j] = VideoTexture.ssd(frames[i], frames[j]);
					//This for loop is the dynamics preservation bit from part 3!
					for (let k = 0; k < 3; k++) {
						ssd.row(i)[j] += VideoTexture.ssd(frames[(i+k) % frames.length], frames[j]);
					}
					ssd.row(i)[j] /= 3.0;
					ssd.row(j)[i] = ssd.row(i)[j];
				}
			}
		}
		return ssd;
	}

	/* calculate unNormalized probabilities, normalize it and return the probabilites as type Matrix */
	static calculateProbabilities(sumSquaredDistances, sigma) {
		
		const len = sumSquaredDistances.length;
		let distributions = new Matrix(len);
		let probabilities = new Matrix(len);
		let sum = 0;
		
		//distributions loop
		for (let i = 0; i < len; i++) {
			
			let min = Number.MAX_SAFE_INTEGER;
			
			for (let j = 0; j < len; j++) {
				if (i!= j) {
					min = Math.min(sumSquaredDistances.row(i)[j], min);
				}
			}
			
			for (let j = 0; j < len; j++) {
				if (i == j) {
					distributions.row(i)[j] = 0.0;
				} else {
					let distribution = Math.exp((-0.0000003*(sumSquaredDistances.row(i)[j] - min))/(2.0 * sigma));
					distributions.row(i)[j] = distribution;
				}
			}
		}
		
		//Probability loop
		for (let i = 0; i < len; i++) {
			sum = 0;
			for (let j = 0; j < len; j++) {
				sum += distributions.row(i)[j];
			}
			for (let j = 0; j < len; j++) {
				probabilities.row(i)[j] = (distributions.row(i)[j] / sum);
			}
		}
		
		return probabilities;
	}

	/* calculate cumulative probabilites using given probabilites of type Matrix and return an object of type Matrix */
	static calculateCumulativeProbabilities(probabilities) {
		
		const len = probabilities.length;
		let cumulativeProbabilities = new Matrix(len);
		
		for (let i = 0; i < len; i++) {
		
			let sum = 0.0;
			for (let j = 0; j < len; j++) {
				sum += probabilities.row(i)[j];
				cumulativeProbabilities.row(i)[j] = sum;
			}
		}
		
		return cumulativeProbabilities;
	}

	/* given a cumulative distribution function of type javascript Array, sample a discrete outcome */
	static sample(cumulativeProbabilities) {
		const n = cumulativeProbabilities.length;
		let i = 0;
		const r = Math.random(0, 1);
		while (r > cumulativeProbabilities[i]) {
			i++;
		}
		if (i >= n) i = Math.floor(r * n);
		return i;
	}
}