var gFrames;
var gSpeed;
var	ssd;
var p;
var cp;
var frame = 0.0;

function preload() {
	// load frames from the given video
	gSpeed = 3; // video speed used while sampling. use 1 for clock and 2 or 3 for candle.mp4
	gFrames = loadVideoFrames("Sundae_Trimmed.mp4", 30, gSpeed);
}

function setup() {
	noStroke();
	createCanvas(windowWidth, windowHeight);
	background(100);
	
	//determines how many time draw() is executed per second
	frameRate(30 / gSpeed);
	
	ssd = VideoTexture.calculateSumSquaredDistances(gFrames);
	p = VideoTexture.calculateProbabilities(ssd, 1);
	cp = VideoTexture.calculateCumulativeProbabilities(p);
	
	verifySSD();
	verifyCalculateSumSquaredDistances();
	verifyCalculateProbabilities();
	verifyCalculateCumulativeProbabilities();
}

function draw() {
	
	if (Math.random(0,1) < 0.2 || frame == cp.length - 1) {
		frame = VideoTexture.sample(cp.row(frame));
	} else {
		frame++;
	}
	
	image(gFrames[frame], 0, 0);
	runVisualizers(25.0);
}

function runVisualizers(size) {
	visualizeSSD(size);
	visualizeP(size);
}

function visualizeSSD(size) {
	
	for (let i = 0; i < ssd.row(frame).length; i++) {
		fill(200 - ssd.row(frame)[i] / 400000.0);
		if (i == frame) {
			fill(255, 0, 0);
		}
		square(i*size, gFrames[frame].height + size/2, size);
	}
}

function visualizeP(size) {
	
	//Establish maximum
	let max = 0.0;
	for (let i = 0; i < p.row(frame).length; i++) {
		if (p.row(frame)[i] > max) {
			max = p.row(frame)[i];
		}
	}
	//And ensure no color exceeds 255 and that the max value is always black
	let scale = 255.0/max;
	
	for (let i = 0; i < p.row(frame).length; i++) {
		fill(255 - scale * p.row(frame)[i]);
		if (i == frame) {
			fill(255, 0, 0);
		}
		square(i*size, gFrames[frame].height + size*2, size);
	}
}