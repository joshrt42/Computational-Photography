var gVideoElement;
var gFps,gSpeed;
var gFutureValue;
var gSelf;
var gRemaining;
var gTotalProcessingTime = 0;
var gTotalProcessingCount = 0;

timeout = function(fps,speed,processingTime) {
	if (gVideoElement.time() < gVideoElement.duration()) {
		setTimeout(function() {
			// console.log('print vid time : ' + gVideoElement.time());
			// console.log("processing Time " + processingTime);
			gTotalProcessingTime += processingTime;
			gTotalProcessingCount += 1;
			const begin = Date.now();
			const remaining = parseInt((gVideoElement.duration() - gVideoElement.time())/speed);
			if (remaining != gRemaining) {
				gRemaining = remaining;
				if (remaining % 2 == 0) {
					console.log((remaining + 1) + " seconds remaining");
				}
			}
			gVideoElement.loadPixels();
			const img = createImage(gVideoElement.width, gVideoElement.height);
			img.loadPixels();
			for (let y = 0; y < img.height; y++) {
				let index = y * img.width * 4;
				for (let x = 0; x < img.width; x++) {
					img.pixels[index] = gVideoElement.pixels[index];
					img.pixels[index + 1] = gVideoElement.pixels[index + 1];
					img.pixels[index + 2] = gVideoElement.pixels[index + 2];
					img.pixels[index + 3] = 255;
					index += 4;
				}
			}
			img.updatePixels();
			gFutureValue.push(img);
			timeout(fps,speed,Date.now()-begin);
		}, Math.max(0,(1000 / fps*speed)-processingTime));
	} else {
		console.log("Finished creating image array from video");
		console.log("Interval between sampling = "+(1000/(fps*speed)));
		console.log("Average processing time per frame : "+(gTotalProcessingTime/gTotalProcessingCount));
		gSelf._decrementPreload();
	}
}

createImageArray = function() {
	console.log(gVideoElement.duration());
	console.log("Creating image array from video");
	gVideoElement.elt.muted = true; // seems like a bug. chrome doesn't allow autoplay without muting the video
	gVideoElement.speed(gSpeed); // increase playback speed for faster sampling
	gVideoElement.play(); // play the video
	gVideoElement.hide(); // hide the video in canvas
	gRemaining = gVideoElement.duration(); // for tracking time
	gVideoElement.loadPixels();
	const img = createImage(gVideoElement.width, gVideoElement.height);
	img.loadPixels();
	for (let y = 0; y < img.height; y++) {
		for (let x = 0; x < img.width; x++) {
			const index = (x + y * img.width) * 4;
			img.pixels[index] = gVideoElement.pixels[index];
			img.pixels[index + 1] = gVideoElement.pixels[index + 1];
			img.pixels[index + 2] = gVideoElement.pixels[index + 2];
			img.pixels[index + 3] = 255;
		}
	}
	img.updatePixels();
	gFutureValue.push(img);
	timeout(gFps,gSpeed,0);
}
/**
 * create and attach a wrapper function for opencv imread to p5 prototype, so that it can be called directly from preload
 * image Mat is copied to the empty Mat that was returned, in the callback function of onload
 * method will be registered as preload method, hence preload() function will wait till _decrementPreload(); is called.
 */
p5.prototype.loadVideoFrames = function(filename, fps, speed) {
	gSelf = this;
	gFutureValue = [];
	gFps = fps;
	gSpeed = speed;
	/* fills images in gFutureValue */
	gVideoElement = createVideo(filename, createImageArray);
	/* returns reference to empty list. preload waits till _decrementPreload,
		 after which gFutureValue will have images extracted from video. */
	return gFutureValue;
}

/**
 * register loadVideoFrames as a preloadMethod so that each call to loadVideoFrames calls _incrementPreload() internally by a wrapper created by p5
 */
p5.prototype.registerPreloadMethod("loadVideoFrames", p5.prototype);