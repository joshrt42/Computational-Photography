class ImageSet {
	constructor(imageInfoList) {
		if (imageInfoList.length == 0) {
			throw Error("Got empty list instead of imageChannelInfoList!");
		}
		this.imageInfoList = imageInfoList
		this.height = imageInfoList[0].image.length;
		this.width = imageInfoList[0].image[0].length;
		this.length = this.imageInfoList.length;

	}

	/* returns exposure value of a given imageID */
	getExposure(id) {
		for (let i = 0; i < this.imageInfoList.length; i++) {
			if (this.imageInfoList[i].id == id) {
				return this.imageInfoList[i].exposure
			}
		}
		throw Error("given ID not found in the set");
	}
	
	/* returns image with given imageID */
	getImage(id) {
		for (let i = 0; i < this.imageInfoList.length; i++) {
			if (this.imageInfoList[i].id == id) {
				return this.imageInfoList[i].image
			}
		}
		throw Error("given ID not found in the set");
	}
	
	/** gets a pixel value for the image with given id
	 *  x is column number and y is the row number
	 */
	getPixelValue(id,x,y){
		const image = this.getImage(id)
		return image[y][x];
	}
}

class ImageSetFactory {
	/* splits imageInfoList into channels and returns 3 imageSets */
	static getImageChannelSets(imageInfoList) {
		/* will have 3 imageChannelInfoList */
		const imageSets = [];
		for (let channel = 0; channel < 3; channel += 1) {
			const imageChannelInfoList = [];
			for (let index = 0; index < imageInfoList.length; index++) {
				const imageChannelInfo = {};
				imageChannelInfo.id = imageInfoList[index].id
				imageChannelInfo.filename = imageInfoList[index].filename
				imageChannelInfo.exposure = imageInfoList[index].exposure
				imageChannelInfo.image = ImageSetFactory.getChannel(imageInfoList[index].image, channel);
				imageChannelInfoList.push(imageChannelInfo);
			}
			imageSets.push(new ImageSet(imageChannelInfoList));
		}
		return imageSets
	}

	static getChannel(image, channel) {
		image.loadPixels();
		const channelImage = new Array(image.height);
		for (let y = 0; y < image.height; y++) {
			channelImage[y] = new Array(image.width);
		}

		for (let y = 0; y < image.height; y++) {
			for (let x = 0; x < image.width; x++) {
				const index = (x + y * image.width) * 4 + channel;
				channelImage[y][x] = image.pixels[index];
			}
		}
		return channelImage;
	}

	/* returns a p5.js displayable image from a 2D array (only for debugging purposes) */
	static getDisplayableImage(channelImage) {
		const image = createImage(channelImage[0].length, channelImage.length);
		image.loadPixels();
		for (let y = 0; y < image.height; y++) {
			for (let x = 0; x < image.width; x++) {
				const index = (x + y * image.width) * 4;
				image.pixels[index] = channelImage[y][x];
				image.pixels[index + 1] = channelImage[y][x];
				image.pixels[index + 2] = channelImage[y][x];
				image.pixels[index + 3] = 255;
			}
		}
		image.updatePixels();
		return image;
	}
}