let gLookupTables, gHDR, gGamma = 1/2.5, gExposureFactor = 10;
let gImageChannelSets, gCurrentLeftImage=0, gAnnotate=true,gColorImage,gToneMappedChannels,gIrradianceChannels;
const gImageInfoList = [
		{ id : 0,filename : "img6.png", exposure : 1.0/10.0},
		{ id : 1,filename : "img5.png", exposure : 1.0/30.0},
		{ id : 2,filename : "img4.png", exposure : 1.0/60.0},
		{ id : 3,filename : "img3.png", exposure : 1.0/125.0},
		{ id : 4,filename : "img2.png", exposure : 1.0/250.0},
		{ id : 5,filename : "img1.png", exposure : 1.0/640.0}
	]

function preload(){
	/* read all images and add it to imageInfoList */
	for (let i = 0; i < gImageInfoList.length; i++) {
		const image = loadImage(gImageInfoList[i].filename);
		gImageInfoList[i].image = image;
	}
}

/* do all estimations and return the output HDR image */
function calculateHDR(){
	gToneMappedChannels = new Array(3);
	for(let channel=0; channel<3; channel++){
		gLookupTables[channel] = gHDR.estimateLookupTable(gImageChannelSets[channel],gIrradianceChannels[channel]);
		gIrradianceChannels[channel] = gHDR.estimateIrradiance(gImageChannelSets[channel],gLookupTables[channel]);
		gToneMappedChannels[channel] = gHDR.toneMap(gIrradianceChannels[channel],gGamma,gExposureFactor);
	}
	const colorImage = gHDR.createColorImage(gToneMappedChannels);
	return colorImage;
}

/* update the tonemap based on gamma and exposure values */
function updateHDRToneMap(irradianceChannels,gamma,exposureFactor){
	for(let channel=0; channel<3; channel++){
		gToneMappedChannels[channel] = gHDR.toneMap(irradianceChannels[channel],gamma,exposureFactor);
	}
	const colorImage = gHDR.createColorImage(gToneMappedChannels);
	return colorImage;
}

/* draw the lookuptable graph */
function displayResponse() {
		let maxX = Number.MIN_SAFE_INTEGER;
		const width = gImageInfoList[0].image.width;
		const height = gImageInfoList[0].image.height;
		for (let c = 0; c < 3; c++) for (let z = 0; z < 256; z++) maxX = Math.max(maxX, isNaN(gLookupTables[c][z]) ? maxX : gLookupTables[c][z]);
		rectMode(CORNER);
		noStroke();
		fill(255);
		rect(2 * width, 0, 255, height - 1);
		stroke(255, 0, 0);
		for (let z = 0; z < 256; z++) point(2 * width + z, height - height * gLookupTables[0][z] / maxX);
		stroke(0, 255, 0);
		for (let z = 0; z < 256; z++) point(2 * width + z, height - height * gLookupTables[1][z] / maxX);
		stroke(0, 0, 255);
		for (let z = 0; z < 256; z++) point(2 * width + z, height - height * gLookupTables[2][z] / maxX);
	}

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	/* calculate and draw HDR image */
	gImageChannelSets = ImageSetFactory.getImageChannelSets(gImageInfoList);
	gLookupTables = HDR.initializeLookupTables();
	gHDR = new HDR(5,250);
	/* generate HDR */
	gIrradianceChannels = new Array(3);
	gToneMappedChannels = new Array(3);
	for(let channel=0; channel<3; channel++){
		gIrradianceChannels[channel] = gHDR.estimateIrradiance(gImageChannelSets[channel],gLookupTables[channel]);
		gToneMappedChannels[channel] = gHDR.toneMap(gIrradianceChannels[channel],gGamma,gExposureFactor);
	}
	gColorImage = gHDR.createColorImage(gToneMappedChannels);
	image(processImage(gImageInfoList[0].image,gAnnotate),0,0);
	image(processImage(gColorImage,gAnnotate),gColorImage.width,0);
	displayResponse();
	/* gamma slider */
	fill(255,255,255)
	text("Gamma slider",gColorImage.width,gColorImage.height+20);
	gGammaSlider = createSlider(10, 100, 50);
  gGammaSlider.position(gColorImage.width,gColorImage.height+30);
	/* exposure factor slider */
	fill(255,255,255)
	text("Exposure slider",gColorImage.width,gColorImage.height+70);
	gExposureFactorSlider = createSlider(1,60,1);
  gExposureFactorSlider.position(gColorImage.width,gColorImage.height+80);
	/* buttons for cycling through images and re-evaluate panorama */
	sourceButton = createButton('Next Source Image');
  sourceButton.position(gColorImage.width/2, gColorImage.height+20);
  sourceButton.mousePressed(cycleSourceImage);
	reEvaluateButton = createButton('Re-evaluate HDR');
  reEvaluateButton.position(gColorImage.width*1.5, gColorImage.height+20);
  reEvaluateButton.mousePressed(reEvaluateHDR);
	annotationButton = createButton('Toggle Annotation');
  annotationButton.position(gColorImage.width*0.5, gColorImage.height+50);
  annotationButton.mousePressed(toggleAnnotation);
	verifyEstimateIrradiance();
	verifyEstimateLookupTable();
	verifyToneMap();
}

/* annotate image if required */
function processImage(image,annotate){
	if(annotate){
		return gHDR.annotateImage(image);
	}
	else{
		return image;
	}
}

function cycleSourceImage() {
	gCurrentLeftImage = (gCurrentLeftImage+1)%gImageInfoList.length;
	image(processImage(gImageInfoList[gCurrentLeftImage].image,gAnnotate),0,0);
}

function reEvaluateHDR(){
	gColorImage = calculateHDR();
	displayResponse();
	image(processImage(gColorImage,gAnnotate),gColorImage.width,0);
}

function toggleAnnotation(){
	gAnnotate = !gAnnotate;
	image(processImage(gImageInfoList[gCurrentLeftImage].image,gAnnotate),0,0);
	image(processImage(gColorImage,gAnnotate),gColorImage.width,0);
}

/* toggle annotation when 'a' or 'A' is pressed */
function keyPressed() {
  if(keyCode == 65 || keyCode == 97){
		gAnnotate = !gAnnotate;
		image(processImage(gImageInfoList[gCurrentLeftImage].image,gAnnotate),0,0);
		image(processImage(gColorImage,gAnnotate),gColorImage.width,0);
	}
}

/* redo tonemapping if alpha or exposure slider changes */
function draw() {
	/* slider doesn't support float, so alpha value is scaled */
	if(gGamma != gGammaSlider.value()/100){
		gGamma = gGammaSlider.value()/100;
		gColorImage = updateHDRToneMap(gIrradianceChannels,gGamma,gExposureFactor);
		image(processImage(gColorImage,gAnnotate),gColorImage.width,0);
	}
	if(gExposureFactor != gExposureFactorSlider.value()){
		gExposureFactor = gExposureFactorSlider.value();
		gColorImage = updateHDRToneMap(gIrradianceChannels,gGamma,gExposureFactor);
		image(processImage(gColorImage,gAnnotate),gColorImage.width,0);
	}
}
		 
		 
		 
		 
		 
		 
		 
		 