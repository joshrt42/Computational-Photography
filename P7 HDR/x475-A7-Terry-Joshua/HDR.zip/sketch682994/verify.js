let lookupA = new Array(256).fill(0).map((val, index) => index);
let lookupB = new Array(256).fill(0).map((val, index) => 10*index);
let lookupC = new Array(256).fill(0).map((val, index) => (index*2)+10);
let lookupE = new Array(13).fill(1).concat(new Array(243).fill(0));
let lookupF = new Array(5).fill(1).concat(new Array(4).fill(2).concat(new Array(4).fill(3).concat(new Array(243).fill(0))));
let lookupG = [1, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4].concat(new Array(243).fill(0));

let irradianceA = [[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]];
let irradianceB = [[10, 20, 30, 40], [10, 20, 30, 40], [10, 20, 30, 40]];
let irradianceC = [[215.55555555555557, 201.66666666666666, 250.625, 470],[380.9666666666667, 263.5416666666667, 327.5, 385.75],[311.6666666666667, 477.5, 529.1666666666666, 436.6666666666667]];
let irradianceD = [[1, 1, 1, 1], [1, 1, 1, 1], [1, 1, 1, 1]];

let toneMapA = [[256, 256, 256, 256], [256, 256, 256, 256], [256, 256, 256, 256]];
let toneMapB = [[64, 128, 192, 256], [64, 128, 192, 256], [64, 128, 192, 256]];
let toneMapC = [[16, 64, 144, 256], [16, 64, 144, 256], [16, 64, 144, 256]];
let toneMapD = [[128, 256, 384, 512], [128, 256, 384, 512], [128, 256, 384, 512]];

function verifyEstimateIrradiance() {
	
	let hdrA = new HDR(0, 21);
	let hdrB = new HDR(20, 200);
	
	// define data for testing
let imageSetA = new ImageSet([
		{ id : 0, exposure : 1, image: [[1, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]]},
		{ id : 1, exposure : 2, image: [[2, 4, 6, 8], [2, 4, 6, 8], [2, 4, 6, 8]]},
		{ id : 2, exposure : 3, image: [[3, 6, 9, 12], [3, 6, 9, 12], [3, 6, 9, 12]]},
		{ id : 3, exposure : 4, image: [[4, 8, 12, 16], [4, 8, 12, 16], [4, 8, 12, 16]]},
		{ id : 4, exposure : 5, image: [[5, 10, 15, 20], [5, 10, 15, 20], [5, 10, 15, 20]]}
]);
let imageSetB = new ImageSet([
		{ id : 0, exposure : 1, image: [[1, 2, 3, 4], [1, -1, 3, 4], [-1, 2, 3, 4]]},
		{ id : 1, exposure : 2, image: [[2, 4, 6, 8], [-1, 4, 6, 8], [2, -1, 6, 8]]},
		{ id : 2, exposure : 3, image: [[3, 6, 9, 12], [3, 6, -1, 12], [3, 6, -1, 12]]},
		{ id : 3, exposure : 4, image: [[4, 8, 12, 16], [4, 8, 12, -1], [4, 8, 12, -1]]},
		{ id : 4, exposure : 5, image: [[5, 10, 15, 20], [-1, -1, -1, -1], [-1, -1, -1, -1]]}
]);
let imageSetC = new ImageSet([
		{ id : 0, exposure : 1, image: [[22, 22, 3, 4], [22, 2, 3, 4], [22, 2, 3, 4]]},
		{ id : 1, exposure : 2, image: [[2, 22, 6, 22], [2, 22, 6, 8], [2, 22, 6, 8]]},
		{ id : 2, exposure : 3, image: [[3, 6, 22, 22], [3, 6, 22, 12], [3, 6, 22, 12]]},
		{ id : 3, exposure : 4, image: [[4, 22, 22, 16], [4, 8, 12, 22], [4, 8, 12, 22]]},
		{ id : 4, exposure : 5, image: [[5, 10, 15, 20], [22, 22, 22, 22], [22, 22, 22, 22]]}
]);
let imageSetD = new ImageSet([
		{ id : 0, exposure : 0.2, image: [[32, 222, 313, 42], [82, 21, 38, 44], [73, 73, 90, 44]]},
		{ id : 1, exposure : 0.4, image: [[253, 232, 60, 222], [83, 84, 63, 88], [42, 83, 60, 73]]},
		{ id : 2, exposure : 0.6, image: [[30, 31, 43, 222], [83, 36, 232, 112], [30, 206, 220, 124]]},
		{ id : 3, exposure : 0.8, image: [[4, 97, 90, 16], [74, 80, 123, 8], [41, 80, 120, 221]]},
		{ id : 4, exposure : 1, image: [[75, 110, 135, 2], [47, 12, 105, 94], [220, 221, 220, 223]]}
]);
	
	let tests = [{
		message: "Testing estimateIrradiance()",
		subtests: [{
				condition: isEqual(hdrA.estimateIrradiance(imageSetA, lookupA), irradianceA),
				errorMsg: "Incorrect irradiance estimate. Check that you are dividing by exposure and averaging (dividing by m) correctly."
			},
			{
				condition: isEqual(hdrA.estimateIrradiance(imageSetB, lookupA), irradianceA),
				errorMsg: "Incorrect irradiance estimate. If the previous test passes and this one fails then you might not be ignoring superblacks correctly."
			},
			{
				condition: isEqual(hdrA.estimateIrradiance(imageSetC, lookupA), irradianceA),
				errorMsg: "Incorrect irradiance estimate. If the previous two tests pass and this one fails then you might not be ignoring superwhites correctly."
			},
			{
				condition: isEqual(hdrA.estimateIrradiance(imageSetC, lookupB), irradianceB),
				errorMsg: "Incorrect irradiance estimate."
			},
			{
				condition: isEqual(hdrB.estimateIrradiance(imageSetD, lookupC), irradianceC),
				errorMsg: "Incorrect irradiance estimate."
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyEstimateLookupTable() {
	
	let imageSetE = new ImageSet([
		{ id : 0, exposure : 1, image: [[0, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]]},
		{ id : 1, exposure : 1, image: [[5, 6, 7, 8], [5, 6, 7, 8], [5, 6, 7, 8]]},
		{ id : 2, exposure : 1, image: [[5, 6, 7, 8], [5, 6, 7, 8], [5, 6, 7, 8]]},
		{ id : 3, exposure : 1, image: [[9, 10, 11, 12], [9, 10, 11, 12], [9, 10, 11, 12]]},
		{ id : 4, exposure : 1, image: [[9, 10, 11, 12], [9, 10, 11, 12], [9, 10, 11, 12]]},
		{ id : 5, exposure : 1, image: [[9, 10, 11, 12], [9, 10, 11, 12], [9, 10, 11, 12]]},
]);
let imageSetF = new ImageSet([
		{ id : 0, exposure : 1, image: [[0, 2, 3, 4], [1, 2, 3, 4], [1, 2, 3, 4]]},
		{ id : 1, exposure : 2, image: [[5, 6, 7, 8], [5, 6, 7, 8], [5, 6, 7, 8]]},
		{ id : 2, exposure : 2, image: [[5, 6, 7, 8], [5, 6, 7, 8], [5, 6, 7, 8]]},
		{ id : 3, exposure : 3, image: [[9, 10, 11, 12], [9, 10, 11, 12], [9, 10, 11, 12]]},
		{ id : 4, exposure : 3, image: [[9, 10, 11, 12], [9, 10, 11, 12], [9, 10, 11, 12]]},
		{ id : 5, exposure : 3, image: [[9, 10, 11, 12], [9, 10, 11, 12], [9, 10, 11, 12]]},
]);
	
	let hdrA = new HDR(0, 21);
	
	let tests = [{
		message: "Testing estimateLookupTable()",
		subtests: [{
				condition: isEqual(hdrA.estimateLookupTable(imageSetE, irradianceD), lookupE),
				errorMsg: "Incorrect lookup table estimate. Check that you are looking up pixel value and averaging the irradiance * exposure correctly"
			},
			{
				condition: isEqual(hdrA.estimateLookupTable(imageSetF, irradianceD), lookupF),
				errorMsg: "Incorrect lookup table estimate. If this check fails but the previous one passes, check that you are multiplying with exposure correctly"
			},
			{
				condition: isEqual(hdrA.estimateLookupTable(imageSetE, irradianceA), lookupG),
				errorMsg: "Incorrect lookup table estimate. If this check fails but the previous two pass, check that you are multiplying with irradiance correctly"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyToneMap() {
	
	let hdrA = new HDR(0, 21);
	
	let tests = [{
		message: "Testing toneMap()",
		subtests: [{
				condition: isEqual(hdrA.toneMap(irradianceD, 1, 1), toneMapA),
				errorMsg: "Incorrect output"
			},
			{
				condition: isEqual(hdrA.toneMap(irradianceA, 1, 1), toneMapB),
				errorMsg: "Incorrect output. If the previous checks pass and this one doesn't, check that you use irradiance divided by max irradiance in the tone mapping formula"
			},
			{
				condition: isEqual(hdrA.toneMap(irradianceA, 2, 1), toneMapC),
				errorMsg: "Incorrect output. If the previous checks pass and this one doesn't, check that you use gamma correctly"
			},
			{
				condition: isEqual(hdrA.toneMap(irradianceA, 1, 2), toneMapD),
				errorMsg: "Incorrect output. If the previous checks pass and this one doesn't, check that you use exposure factor correctly"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function runTests(tests) {

	// run tests
	tests.forEach(test => {

		// print test message
		println(test.message.toUpperCase());
		println(" ");

		// run subtests for this test
		let failed = 0; // number of subtests failed

		for (let i = 0; i < test.subtests.length; i++) {

			let subtest = test.subtests[i];

			if (subtest.condition) {
				println("Check " + (i + 1) + " passed");
			} else {
				failed++;
				println("Check " + (i + 1) + " failed: " + subtest.errorMsg);
			}
		}
		println(" ");

		// all subtests passed
		if (failed === 0) {
			println("All checks passed.");
		} else {
			println(failed + " out of " + test.subtests.length + " checks failed.");
		}

		println("______________________________________________");

	});
}

// utility function to check if two arrays / objects are equal
function isEqual(a, b) {
	return objectHash.sha1(a) === objectHash.sha1(b);
}