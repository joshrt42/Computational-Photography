class HDR {
	constructor(superblack, superwhite) {
		this.superblack = superblack;
		this.superwhite = superwhite;
	}

	static initializeLookupTables() {
		const lookupTables = new Array(3);
		for (let i = 0; i < lookupTables.length; i++) {
			lookupTables[i] = new Array(256);
			for (let j = 0; j < 256; j++) {
				lookupTables[i][j] = (1000.0 - 100 * i) * j / 255.0;
			}
		}
		return lookupTables;
	}

	/* estimate irradiance from images */
	estimateIrradiance(imageSet, lookupTable) {
		/* initialize irradiance 2D array */
		const irradiance = new Array(imageSet.height);
		for (let y = 0; y < imageSet.height; y++) {
			irradiance[y] = new Array(imageSet.width);
		}

		for (let y = 0; y < imageSet.height; y++) {
			for (let x = 0; x < imageSet.width; x++) {
				let g = 0.0;
				let m = 0;
				for (let id = 0; id < imageSet.length; id++) {
				/*
		 		 * INSERT/MODIFY CODE BELOW AS INSTRUCTED IN PART 2.1 OF THE ASSIGNMENT
	 	 		 */
					let value = imageSet.getPixelValue(id, x, y);
					if (value > this.superblack && value < this.superwhite) {
						g += lookupTable[value] / imageSet.getExposure(id);
						m += 1;
					}
				}
				irradiance[y][x] = (m == 0 ? NaN : g / m);
			}
		}
		return irradiance;
	}

	/* estimate LookupTable from images */
	estimateLookupTable(imageSet, irradiance) {
		const sum = new Array(256).fill(0);
		const count = new Array(256).fill(0);
		/* calculate the sum and count */
		for (let y = 0; y < imageSet.height; y++) {
			for (let x = 0; x < imageSet.width; x++) {
				for (let id = 0; id < imageSet.length; id++) {
				/*
		 		 * INSERT/MODIFY CODE BELOW AS INSTRUCTED IN PART 2.2 OF THE ASSIGNMENT
	 	 		 */
					let value = imageSet.getPixelValue(id, x, y);
					let irr = irradiance[y][x] * imageSet.getExposure(id);
					sum[value] += irr;
					if (irr > 0) {
						count[value] += 1;
					}
				}
			}
		}
		/* calculate new values for lookup table */
		const lookupTable = new Array(256);
		for (let z = 0; z < 256; z++) {
			lookupTable[z] = count[z] == 0 ? 0 : sum[z] / count[z];
		}
		return lookupTable;
	}

	/* tone maps a single channel */
	toneMap(irradiance, gamma, exposureFactor) {
		const height = irradiance.length;
		const width = irradiance[0].length;
		let maxIrradiance = Number.MIN_SAFE_INTEGER;
		let minIrradiance = Number.MAX_SAFE_INTEGER;
		/* calculate min and max values */
		for (let y = 0; y < height; y++) {
			for (let x = 0; x < width; x++) {
				minIrradiance = Math.min(minIrradiance, isNaN(irradiance[y][x]) ? minIrradiance : irradiance[y][x]);
				maxIrradiance = Math.max(maxIrradiance, isNaN(irradiance[y][x]) ? maxIrradiance : irradiance[y][x]);
			}
		}
		/* create a 2D array */
		let toneMappedChannel = new Array(height);
		for (let y = 0; y < height; y++) {
			toneMappedChannel[y] = new Array(width);
		}
		for (let y = 0; y < height; y++) {
			for (let x = 0; x < width; x++) {
				/*
		 		 * INSERT/MODIFY CODE BELOW AS INSTRUCTED IN PART 2.3 OF THE ASSIGNMENT
	 	 		 */
				if (irradiance[y][x] == NaN) {
					toneMappedChannel[y][x] = 0.0;
				} else {
					toneMappedChannel[y][x] = 256 * Math.pow((exposureFactor * irradiance[y][x] / maxIrradiance),(gamma));
				}
			}
		}
		return toneMappedChannel;
	}
	
	/* annotates a pixel with red,green or blue based on the pixel type */
	static annotatePixel(image,index,superwhite,superblack,nan){
		let r,g,b;
		if(superwhite){
			r = 0; g = 255; b = 0;
		}
		else if(superblack){
			r = 0; g = 0; b = 255;
		}
		else if(nan){
			r = 255; g = 0; b = 0;
		}
		if(superwhite || superblack || nan){
			image.pixels[index] = r;
			image.pixels[index+1] = g;
			image.pixels[index+2] = b;
		}
	}
	
	/* annotates an image using annotatePixel method */
	annotateImage(image){
		const newImage = createImage(image.width,image.height);
		newImage.loadPixels();
		for (let y = 0; y < image.height; y++) {
			for (let x = 0; x < image.width; x++) {
				let isNanPixel = false, isSuperblackPixel = false, isSuperwhitePixel = false;
				let index = (x + y * image.width) * 4;
				for(let channel = 0; channel<3;channel++){
					const pixelValue = image.pixels[index+channel];
					isSuperblackPixel = pixelValue<this.superblack;
					isSuperwhitePixel = pixelValue>this.superwhite;
					isNanPixel = isNaN(pixelValue);
					newImage.pixels[index+channel] = pixelValue;
				}
				/* set alpha to 255 */
				newImage.pixels[index+3] = 255;
				/* if extreme pixels, change color */
				HDR.annotatePixel(newImage,index,isSuperwhitePixel,isSuperblackPixel,isNanPixel)
			}
		}
		newImage.updatePixels();
		return newImage;
	}
	

/* creates a color image from toneMappedImageChannels */
	createColorImage(toneMappedChannels) {
		/* create new image. parameters are (width,height) */
		const image = createImage(toneMappedChannels[0][0].length, toneMappedChannels[0].length)
		image.loadPixels();
		for (let y = 0; y < image.height; y++) {
			for (let x = 0; x < image.width; x++) {
				let index = (x + y * image.width) * 4;
				for(let channel = 0; channel<3;channel++){
					const pixelValue = toneMappedChannels[channel][y][x];
					image.pixels[index+channel] = pixelValue;
				}
				/* set alpha to 255 */
				image.pixels[index+3] = 255;
			}
		}
		image.updatePixels();
		return image;
	}

}