let points = 0;
let maxPoints = 0;

// called from the sketch to execute tests
function verifyGetBlackImage() {

	
	// define tests. each test has a set of subtests that all need to be passed for the student to be awarded the points specified
	let tests = [
		{
			message: "Testing getBlackImage",
			points: 2,
			subtests: [
				{ 
					condition: getBlackImage(2, 1, 24).rows === 2 && getBlackImage(1, 3, gResizedImage1.type()).cols === 3,
					errorMsg: "getBlackImage does not produce an output of the correct dimensions"
				},
				{ 
					condition: isEqual(getBlackImage(2, 2, 24).data, Uint8Array.from([0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255])),
					errorMsg: "getBlackImage(2, 2, type does not produce a 2 by 2 black image"
				},
				{ 
					condition: isEqual(getBlackImage(1, 1, 24).data, Uint8Array.from([0, 0, 0, 255])),
					errorMsg: "getBlackImage(1, 1, type does not produce one black RGBA pixel"
				}
			]
		}
	];

	//console.log('Preliminary grade: ' + points + ' out of ' + maxPoints);

	// run tests
	runTests(tests);
}

// called from the sketch to execute tests
function verifyRelighting() {

	// create data for testing purposes here
	let i1 = new cv.Mat(2, 2, 24, new cv.Scalar(20, 20, 20, 255));
	let i2 = new cv.Mat(2, 2, 24, new cv.Scalar(40, 40, 40, 255));
	let i3 = new cv.Mat(2, 2, 24, new cv.Scalar(60, 60, 60, 255));
	let i4 = new cv.Mat(2, 2, 24, new cv.Scalar(0, 0, 0, 255));

	
	// define tests. each test has a set of subtests that all need to be passed for the student to be awarded the points specified
	let tests = [
		{
			message: "Testing relighting",
			points: 2,
			subtests: [
				{ 
					condition: isEqual(relight(i1, i2, i3, i4, 255, 0, 0).data, Uint8Array.from([20, 20, 20, 255, 20, 20, 20, 255, 20, 20, 20, 255, 20, 20, 20, 255])),
					errorMsg: "When image slider 1 is set to max, but the other sliders are set to zero, the output should equal the first image, but it does not",
				},
				{ 
					condition: isEqual(relight(i1, i2, i3, i4, 0, 255, 0).data, Uint8Array.from([40, 40, 40, 255, 40, 40, 40, 255, 40, 40, 40, 255, 40, 40, 40, 255])),
					errorMsg: "When image slider 2 is set to max, but the other sliders are set to zero, the output should equal the second image, but it does not",
				},
				{ 
					condition: isEqual(relight(i1, i2, i3, i4, 0, 0, 255).data, Uint8Array.from([60, 60, 60, 255, 60, 60, 60, 255, 60, 60, 60, 255, 60, 60, 60, 255])),
					errorMsg: "When image slider 3 is set to max, but the other sliders are set to zero, the output should equal, but it does not",
				},
				{ 
					condition: isEqual(relight(i1, i2, i3, i4, 255, 0, 255).data, Uint8Array.from([80, 80, 80, 255, 80, 80, 80, 255, 80, 80, 80, 255, 80, 80, 80, 255])),
					errorMsg: "When image slider 1 and image slider 2 is set to max but the third slider is set to zero, the output should equal the first image, but it is not",
				}
			]
		}
	];

	// run tests
	runTests(tests);

	//console.log('Preliminary grade: ' + points + ' out of ' + maxPoints);
}

function runTests(tests) {

	// run tests
	tests.forEach(test => {

		// print test message
		println(test.message.toUpperCase());
		println(" ");

		// run subtests for this test
		let failed = 0; // number of subtests failed
		
		for(let i = 0; i < test.subtests.length; i++) {

			let subtest = test.subtests[i];

			if(subtest.condition) {
				println("Check " + (i+1) + " passed");
			} else {
				failed++;
				println("Check " + (i+1) + " failed: " + subtest.errorMsg, 'color: #c01025');
			}
		}
		println(" ");

		// all subtests passed
		if(failed === 0) {
			println("All checks passed.", 'color: #0b6623');
			// award the student points
			points += test.points;
		} else {
			println(failed + " out of " + test.subtests.length + " checks failed.", 'color: #c01025');
		}

		// update max grade
		maxPoints = maxPoints + test.points;
		
		println("______________________________________________");
  		
	});
}

// utility function to check if two arrays are equal
function isEqual(a, b) {
	return objectHash.sha1(a) === objectHash.sha1(b);
	// use Lodash to comapre arrays
    //return _.isEqual(a, b);
}