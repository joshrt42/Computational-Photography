var gSlider1;
var gSlider2;
var gSlider3;
var gImage1;
var gImage2;
var gImage3;
var gResizedImage1;
var gResizedImage2;
var gResizedImage3;
var gCannyImage;
var gOutputCanvas;
var gBlackImage

function preload() {
	gImage1 = loadOpencvImage('IMG_0511-small.jpg');
	gImage2 = loadOpencvImage('IMG_0534-small.jpg');
	gImage3 = loadOpencvImage('IMG_0554-small.jpg');
}

function getBlackImage(rows, cols) {
	return new cv.Mat(rows, cols, 24, new cv.Scalar(0,0,0,255));
}

function relight(image1, image2, image3, blackImage, sliderValue1, sliderValue2, sliderValue3) {
	const output = new cv.Mat();
	cv.addWeighted(image1, sliderValue1/255, blackImage, 1, 0.0, output);
	cv.addWeighted(image2, sliderValue2/255, output, 1, 0.0, output);
	cv.addWeighted(image3, sliderValue3/255, output, 1, 0.0, output);
	return output;
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	
	background(15,70,80);
	
	gSlider1 = createSlider(0,255,0);
	gSlider1.position(635.7, 377);
	gSlider2 = createSlider(0,255,0);
	gSlider2.position(635.7, 407);
	gSlider3 = createSlider(0,255,0);
	gSlider3.position(635.7, 437);
	
	gResizedImage1 = new cv.Mat();
	gResizedImage2 = new cv.Mat();
	gResizedImage3 = new cv.Mat();
	
	const factor = 0.15
	const dsize = new cv.Size(round(factor * gImage1.cols), round(factor * gImage1.rows));
	
	cv.resize(gImage1, gResizedImage1, dsize, 0, 0, cv.INTER_AREA);
  cv.resize(gImage2, gResizedImage2, dsize, 0, 0, cv.INTER_AREA);
	cv.resize(gImage3, gResizedImage3, dsize, 0, 0, cv.INTER_AREA);

	
	const imageCanvas1 = createOpencvCanvas(0, 0);
	const imageCanvas2 = createOpencvCanvas(gResizedImage1.cols, 0);
	const imageCanvas3 = createOpencvCanvas(gResizedImage1.cols*2, 0);
	
	cv.imshow(imageCanvas1, gResizedImage1);
	cv.imshow(imageCanvas2, gResizedImage2);
	cv.imshow(imageCanvas3, gResizedImage3);
	
	gBlackImage = getBlackImage(gResizedImage1.rows, gResizedImage1.cols);
	
	gCannyImage = new cv.Mat();
	cv.Canny(gResizedImage1, gCannyImage, 50, 100, 3, false);
	gOutputCanvas = createOpencvCanvas(gResizedImage1.cols, gResizedImage1.rows + 100);
	verifyRelighting();
}

function draw() {
	const sliderValue1 = gSlider1.value();
	const sliderValue2 = gSlider2.value();
  const sliderValue3 = gSlider3.value();
	
	const output = relight(gResizedImage1, gResizedImage2, gResizedImage3, gBlackImage, sliderValue1, sliderValue2, sliderValue3);
	
	cv.imshow(gOutputCanvas, output);
	output.delete();
}