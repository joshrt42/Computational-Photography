/**
 * create and attach a wrapper function for opencv imread to p5 prototype, so that it can be called directly from preload
 * image Mat is copied to the empty Mat that was returned, in the callback function of onload
 * method will be registered as preload method, hence preload() function will wait till _decrementPreload(); is called.
 */
p5.prototype.loadOpencvImage = function (path) {
	var futureValue = new cv.Mat();
	var self = this;
	const imageElement = document.createElement('img');
	imageElement.style.display = 'none'; // hide the image
	imageElement.crossOrigin = 'Anonymous'; // very important!
	/**
	 * callback that gets invoked when async loading of image is complete
	 */
	imageElement.onload = () => {
		const imageMatrix = cv.imread(imageElement);
		imageMatrix.copyTo(futureValue);
		self._decrementPreload();
	}
	imageElement.src = path; // async call that load the image from the given path
	return futureValue;
}

/**
 * returns a new canvas element that is required for opencv to display an image
 * imshow resizes the canvas to the required size, so size doesn't have to be specified separately.
 */
p5.prototype.createOpencvCanvas = function (leftMargin, topMargin) {
	const canvas = document.createElement('canvas');
	canvas.style.position = 'absolute';
	canvas.style.marginLeft = `${leftMargin}px`;
	canvas.style.marginTop = `${topMargin}px`;
	canvas.style.zIndex = 1; // makes sure that the canvas is visible even if p5 canvas is drawn above it
	document.body.appendChild(canvas);
	return canvas;
}

/**
 * register loadOpencvImage as a preloadMethod so that each call to loadOpencvImage calls _incrementPreload() internally by a wrapper created by p5
 */
p5.prototype.registerPreloadMethod("loadOpencvImage", p5.prototype);
