/**
 * Handles operations related to creating and drawing quadrilateral
 */

class Pane {
	constructor(x, y, image) {
		this.x0 = x;
		this.y0 = y;
		this.width = image.cols;
		this.height = image.rows;
		this.image = image;
		this.imageCopy = this.image.clone();
		this.numberOfVertices = 4;
		this.chosen = -1
		this.vertices = [[this.width/4, this.height/4],[this.width*3/4, this.height/4],[this.width*3/4, this.height*3/4],[this.width/4, this.height*3/4]];
	}
	
	/** overwrites imageCopy with a fresh copy of image */
	clearQuadrangle() {
		this.imageCopy.delete();
		this.imageCopy = new cv.Mat();
		this.imageCopy = this.image.clone();
	}
	
	/** returns the image */
	getImage() {
		return this.imageCopy.clone();
	}
	
	/** Draws quadrilaterals onto the given image. image is pass by reference and will be modified */
	drawQuadrangle() {
		this.clearQuadrangle();
		const color = new cv.Scalar(0,0,0,255);
		const thickness = 1;
	
		cv.line(this.imageCopy, new cv.Point(parseInt(this.vertices[0][0]), parseInt(this.vertices[0][1])), new cv.Point(parseInt(this.vertices[1][0]), parseInt(this.vertices[1][1])), color, thickness);
		cv.line(this.imageCopy, new cv.Point(parseInt(this.vertices[1][0]), parseInt(this.vertices[1][1])), new cv.Point(parseInt(this.vertices[2][0]), parseInt(this.vertices[2][1])), color, thickness);
		cv.line(this.imageCopy, new cv.Point(parseInt(this.vertices[2][0]), parseInt(this.vertices[2][1])), new cv.Point(parseInt(this.vertices[3][0]), parseInt(this.vertices[3][1])), color, thickness);
		cv.line(this.imageCopy, new cv.Point(parseInt(this.vertices[3][0]), parseInt(this.vertices[3][1])), new cv.Point(parseInt(this.vertices[0][0]), parseInt(this.vertices[0][1])), color, thickness);		
		
		cv.putText(this.imageCopy, '1', new cv.Point(parseInt(this.vertices[0][0])-10, parseInt(this.vertices[0][1])-10), cv.FONT_HERSHEY_SIMPLEX, 0.5, color,thickness);
		cv.putText(this.imageCopy, '2', new cv.Point(parseInt(this.vertices[1][0])+10, parseInt(this.vertices[1][1])-10), cv.FONT_HERSHEY_SIMPLEX, 0.5, color,thickness);
		cv.putText(this.imageCopy, '3', new cv.Point(parseInt(this.vertices[2][0])+10, parseInt(this.vertices[2][1])+10), cv.FONT_HERSHEY_SIMPLEX, 0.5, color,thickness);
		cv.putText(this.imageCopy, '4', new cv.Point(parseInt(this.vertices[3][0])-10, parseInt(this.vertices[3][1])+10), cv.FONT_HERSHEY_SIMPLEX, 0.5, color,thickness);
	}
	
	/** choose a vertex to be updated, based on proximity to the mouse pointer */
	selectVertex(mouseX, mouseY) {
		const x = mouseX - this.x0;
		const y = mouseY - this.y0;
		this.chosen = -1;
		let minSqrtDistance = Number.MAX_VALUE
		for (let i = 0; i < this.numberOfVertices; i++) {
			const sqrtDistance = Math.pow(this.vertices[i][0] - x, 2) + Math.pow(this.vertices[i][1] - y, 2)
			if (sqrtDistance < minSqrtDistance) {
				this.chosen = i;
				minSqrtDistance = sqrtDistance;
			}
		}
	}

	/** updates the a single vertex based on mouse location */
	updateVertex(mouseX, mouseY) {
		if(this.chosen>-1){
			const x = mouseX - this.x0;
			const y = mouseY - this.y0;
			if (x < 0 || x > this.width || y < 0 || y >= this.height) {
				return;
			} else {
				this.vertices[this.chosen][0] = x;
				this.vertices[this.chosen][1] = y;
			}
		}		
	}
	
}