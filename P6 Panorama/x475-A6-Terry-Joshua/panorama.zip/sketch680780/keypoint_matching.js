/** global variables used across preload, setup, and draw */
let gImage1, gImage2, gImageR
let outputImage1, outputImage2, outputImageR
let imageFeatures1, imageFeatures2, imageFeaturesR, imageFeaturesI
let outputCanvas1, outputCanvas2, outputCanvasR

let comparePane1, comparePane2, chosenPane, matchMode, displayMode

function preload() {
	gImage1 = loadOpencvImage('left_image.jpg');
	gImage2 = loadOpencvImage('right_image.jpg');
	gImageR = loadOpencvImage('reference_image.jpg');
}

function setup() {
	/** create p5.js canvas and background color */
	createCanvas(windowWidth, windowHeight);
	background(100);
	
	const imageCanvas = createOpencvCanvas(0, 0);;
	
	/** create output canvas */
	var u = gImage1.cols
	var v = gImage1.rows
	outputCanvas1 = createOpencvCanvas(0, 0);
	outputCanvas2 = createOpencvCanvas(u*2.2,0);
	outputCanvasR = createOpencvCanvas(u*1.1,0);

	/** initialize panes */
	pane1 = new Pane(0,0,gImage1);
	pane2 = new Pane(u*2.2,0,gImage2);
	paneR = new Pane(u*1.1,0,gImageR);
	
	/** draw Quadrangles*/
	pane1.drawQuadrangle();
	pane2.drawQuadrangle();
	paneR.drawQuadrangle();
	
	cv.imshow(outputCanvas1,gImage1);
	cv.imshow(outputCanvas2,gImage2);
	cv.imshow(outputCanvasR,gImageR);
	
	/** initialize modes*/
	matchMode = -1 // -1 is default mode, 1 is feature matching mode
	displayMode = -1 // this is to select the display of left or right images

}

function draw() {
	clear()
	pane1.drawQuadrangle();
	pane2.drawQuadrangle();
	paneR.drawQuadrangle();
	outputImage1 = pane1.getImage();
	outputImage2 = pane2.getImage();
	outputImageR = paneR.getImage();
	
	/** Match features between the left image and the reference image*/
	if(displayMode == 1){
		cv.imshow(outputCanvas1,outputImage1);
		cv.imshow(outputCanvas2,gImage2);
		cv.imshow(outputCanvasR,outputImageR);
		imageFeaturesI = pane1.vertices
		imageFeaturesR = paneR.vertices
	}
	
	/** Match features between the right image and the reference image*/
	else if(displayMode == 2){
		cv.imshow(outputCanvas1,gImage1);
		cv.imshow(outputCanvas2,outputImage2);
		cv.imshow(outputCanvasR,outputImageR);
		imageFeaturesI = pane2.vertices
		imageFeaturesR = paneR.vertices
	}
	else{
		cv.imshow(outputCanvas1,gImage1);
		cv.imshow(outputCanvas2,gImage2);
		cv.imshow(outputCanvasR,gImageR);
	}
	outputImage1.delete()
	outputImage2.delete()
	outputImageR.delete()
}

function keyPressed(){
	
	/** Button `1` */
	if(keyCode == 49){
		comparePane1 = pane1
		comparePane2 = paneR
		matchMode = 1
		displayMode = 1 
	}
	/** Button `2` */
	else if(keyCode == 50){
		comparePane1 = pane2
		comparePane2 = paneR
		matchMode = 1
		displayMode = 2
	}
	else if(key == 'p'){
		print("imageFeatures" + displayMode + ":")
		print("["+imageFeaturesI[0][0]+","+imageFeaturesI[0][1]+","+imageFeaturesI[1][0]+","+imageFeaturesI[1][1]+","
					+imageFeaturesI[2][0]+","+imageFeaturesI[2][1]+","+imageFeaturesI[3][0]+","+imageFeaturesI[3][1]+"]")
		print("imageFeaturesR:")
		print("["+imageFeaturesR[0][0]+","+imageFeaturesR[0][1]+","+imageFeaturesR[1][0]+","+imageFeaturesR[1][1]+","+
					+imageFeaturesR[2][0]+","+imageFeaturesR[2][1]+","+imageFeaturesR[3][0]+","+imageFeaturesR[3][1]+"]")
	}
	else if(key == 'c'){
		matchMode = -1
		displayMode = -1
	}
}

/** choose a pane to edit vertices, based on proximity to mouse pointer */
function mousePressed(){
	if(matchMode == 1){
		const pane1Distance = Math.pow((comparePane1.x0+comparePane1.width/2)-mouseX,2) + Math.pow((comparePane1.y0+comparePane1.height/2)-mouseY,2)
		const pane2Distance = Math.pow((comparePane2.x0+comparePane2.width/2)-mouseX,2) + Math.pow((comparePane2.y0+comparePane2.height/2)-mouseY,2)
		if(pane1Distance < pane2Distance){
			chosenPane = comparePane1;
		}
		else{
			chosenPane = comparePane2;
		}
		chosenPane.selectVertex(mouseX,mouseY);
	}
}

/** update the chosen vertex in chosen pane */
function mouseDragged(){
	if(matchMode == 1){
		chosenPane.updateVertex(mouseX,mouseY);
	}	
}