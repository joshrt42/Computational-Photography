class KltParams {
	/* constructs parameters for KLT using default values */
	constructor() {
		this.winSize = new cv.Size(20, 20);
		this.maxLevel = 2;
		this.criteria = new cv.TermCriteria(cv.TERM_CRITERIA_EPS | cv.TERM_CRITERIA_COUNT, 10, 0.03);
	}
}