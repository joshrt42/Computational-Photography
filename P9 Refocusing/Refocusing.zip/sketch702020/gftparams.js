class GftParams {
	/* constructs parameters for GoodFeaturesToTrack using default values */
	constructor() {
		this.maxCorners = 100;
		this.qualityLevel = 0.1;
		this.minDistance = 50;
		this.blockSize = 3;
	}
}