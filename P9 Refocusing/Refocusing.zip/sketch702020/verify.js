function verifyInitializeTracks() {
	
	let openCVImages = Refocuser.getOpencvImages(gImages.slice(0,3));

	let params = new GftParams(); // default parameters

	let tracks1 = new Tracks();
	tracks1.data = [[new cv.Point(324,263)],[new cv.Point(207,181)],[new cv.Point(407,248)],[new cv.Point(260,256)],[new cv.Point(163,206)],[new cv.Point(146,305)],[new cv.Point(242,141)],[new cv.Point(484,360)],[new cv.Point(322,205)],[new cv.Point(408,176)],[new cv.Point(209,280)],[new cv.Point(40,108)],[new cv.Point(482,56)],[new cv.Point(111,203)],[new cv.Point(38,32)],[new cv.Point(73,282)],[new cv.Point(323,155)],[new cv.Point(256,201)]];
	let tracks2 = new Tracks();
	tracks2.data = [[new cv.Point(340,262)],[new cv.Point(221,180)],[new cv.Point(448,168)],[new cv.Point(515,359)],[new cv.Point(172,303)],[new cv.Point(229,277)],[new cv.Point(257,139)],[new cv.Point(434,246)],[new cv.Point(338,204)],[new cv.Point(274,253)],[new cv.Point(125,201)],[new cv.Point(469,59)],[new cv.Point(54,107)],[new cv.Point(182,246)],[new cv.Point(53,31)]];
	let tracks3 = new Tracks();
	tracks3.data = [[new cv.Point(352,257)],[new cv.Point(231,174)],[new cv.Point(464,160)],[new cv.Point(244,272)],[new cv.Point(268,134)],[new cv.Point(191,297)],[new cv.Point(454,242)],[new cv.Point(324,161)],[new cv.Point(480,40)],[new cv.Point(537,353)],[new cv.Point(134,195)],[new cv.Point(63,25)],[new cv.Point(64,101)],[new cv.Point(194,239)],[new cv.Point(381,321)],[new cv.Point(115,274)],[new cv.Point(408,169)]];
	
	let tests = [{
		message: "Testing initializeTracks()",
		subtests: [{
				condition: isEqual(Refocuser.initializeTracks(openCVImages[0], params), tracks1),
				errorMsg: "Incorrect output."
			},
			{
				condition: isEqual(Refocuser.initializeTracks(openCVImages[1], params), tracks2),
				errorMsg: "Incorrect output."
			},
			{
				condition: isEqual(Refocuser.initializeTracks(openCVImages[2], params), tracks3),
				errorMsg: "Incorrect output."
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyExtendTracks() {
	
	let openCVImages = Refocuser.getOpencvImages(gImages.slice(0,3));

	let params = new KltParams(); // default parameters

	let tracks1 = new Tracks();
	tracks1.data = [[new cv.Point(324,263)],[new cv.Point(207,181)],[new cv.Point(407,248)],[new cv.Point(260,256)],[new cv.Point(163,206)],[new cv.Point(146,305)],[new cv.Point(242,141)],[new cv.Point(484,360)],[new cv.Point(322,205)],[new cv.Point(408,176)],[new cv.Point(209,280)],[new cv.Point(40,108)],[new cv.Point(482,56)],[new cv.Point(111,203)],[new cv.Point(38,32)],[new cv.Point(73,282)],[new cv.Point(323,155)],[new cv.Point(256,201)]];
	let tracks2 = new Tracks();
	tracks2.data = [[new cv.Point(340,262)],[new cv.Point(221,180)],[new cv.Point(448,168)],[new cv.Point(515,359)],[new cv.Point(172,303)],[new cv.Point(229,277)],[new cv.Point(257,139)],[new cv.Point(434,246)],[new cv.Point(338,204)],[new cv.Point(274,253)],[new cv.Point(125,201)],[new cv.Point(469,59)],[new cv.Point(54,107)],[new cv.Point(182,246)],[new cv.Point(53,31)]];

	let tests = [{
		message: "Testing extendTracks()",
		subtests: [{
				condition: objectHash.sha1(Refocuser.extendTracks(openCVImages[0], openCVImages[1], tracks1, params)) === "30353839bada5af277b7e6d46a5b60f73e2953ad",
				errorMsg: "Incorrect output"
			},
			{
				condition: objectHash.sha1(Refocuser.extendTracks(openCVImages[1], openCVImages[2], tracks2, params)) === "dc68285bf6dd75d5af113004aaf76e90fedbfab1",
				errorMsg: "Incorrect output"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyGetImageTracks() {
	
	let openCVImagesAll = Refocuser.getOpencvImages(gImages);
	let openCVImages1 = openCVImagesAll.slice(0,3);
	let openCVImages2 = openCVImagesAll.slice(3,6);
	let openCVImages3 = openCVImagesAll.slice(6,9);
	
	let tests = [{
		message: "Testing getImageTracks()",
		subtests: [{
				condition: objectHash.sha1(Refocuser.getImageTracks(openCVImages1)) === "24e9a8e8f04069b4dd33584860751860ccf50151",
				errorMsg: "Incorrect output"
			},
		  {
				condition: objectHash.sha1(Refocuser.getImageTracks(openCVImages2)) === "50467dd5baa25fe62dd6535c2e58b76106b618a1",
				errorMsg: "Incorrect output"
			},
			{
				condition: objectHash.sha1(Refocuser.getImageTracks(openCVImages3)) === "86afb33f35c091aa42aca102bae27b0008a5af0b",
				errorMsg: "Incorrect output"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function verifyRefocus() {
	
	let image1 = createImage(4, 3);
	image1.loadPixels();
	image1.pixels = [10, 10, 10, 255, 20, 20, 20, 255, 30, 30, 30, 255, 40, 40, 40, 255, 50, 50, 50, 255, 60, 60, 60, 255, 70, 70, 70, 255, 80, 80, 80, 255, 90, 90, 90, 255, 100, 100, 100, 255, 90, 100, 80, 255, 70, 110, 60, 255]
	
	let image2 = createImage(4, 3);
	image2.loadPixels();
	image2.pixels = [10, 16, 10, 255, 0, 0, 0, 255, 10, 10, 10, 255, 20, 20, 20, 255, 30, 0, 0, 255, 0, 0, 0, 255, 40, 60, 70, 255, 0, 10, 20, 255, 40, 10, 10, 255, 30, 50, 90, 255, 60, 60, 60, 255, 30, 30, 30, 255]
	
	let image3 = createImage(4, 3);
	image3.loadPixels();
	image3.pixels = [10, 16, 10, 255, 0, 0, 0, 255, 10, 10, 10, 255, 20, 20, 20, 255, 30, 0, 0, 255, 0, 0, 0, 255, 40, 60, 70, 255, 0, 10, 20, 255, 40, 10, 10, 255, 30, 50, 90, 255, 60, 60, 60, 255, 30, 30, 30, 255]
	
	let image4 = createImage(4, 3);
	image4.loadPixels();
	image4.pixels = [10, 16, 10, 255, 0, 0, 0, 255, 10, 10, 10, 255, 20, 20, 20, 255, 30, 0, 0, 255, 0, 0, 0, 255, 40, 60, 70, 255, 0, 10, 20, 255, 40, 10, 10, 255, 30, 50, 90, 255, 60, 60, 60, 255, 30, 30, 30, 255]
	
	let images = [image1, image2];
	
	let track1 = [new cv.Point(0,0), new cv.Point(0,0)];
	let track2 = [new cv.Point(1,1), new cv.Point(2,0)];
	let track3 = [new cv.Point(0,1), new cv.Point(2,2)];
	
	let image3Pixels = new Uint8ClampedArray([10, 13, 10, 255, 10, 10, 10, 255, 20, 20, 20, 255, 30, 30, 30, 255, 40, 25, 25, 255, 30, 30, 30, 255, 55, 65, 70, 255, 40, 45, 50, 255, 65, 50, 50, 255, 65, 75, 95, 255, 75, 80, 70, 255, 50, 70, 45, 255]);
	let image4Pixels = new Uint8ClampedArray([5, 5, 5, 255, 10, 10, 10, 255, 15, 15, 15, 255, 20, 20, 20, 255, 25, 25, 25, 255, 35, 35, 35, 255, 45, 45, 45, 255, 40, 40, 40, 255, 45, 45, 45, 255, 70, 80, 85, 255, 45, 55, 50, 255, 35, 55, 30, 255]);
	let image5Pixels = new Uint8ClampedArray([25, 35, 40, 255, 10, 15, 20, 255, 15, 15, 15, 255, 20, 20, 20, 255, 55, 55, 55, 255, 45, 45, 45, 255, 35, 35, 35, 255, 40, 40, 40, 255, 45, 45, 45, 255, 50, 50, 50, 255, 45, 50, 40, 255, 35, 55, 30, 255]);
	
	let tests = [{
		message: "Testing refocus()",
		subtests: [{
				condition: isEqual(Refocuser.refocus(images, track1).pixels, image3Pixels),
				errorMsg: "Incorrect output"
			},
			{
				condition: isEqual(Refocuser.refocus(images, track2).pixels, image4Pixels),
				errorMsg: "Incorrect output"
			},
			{
				condition: isEqual(Refocuser.refocus(images, track3).pixels, image5Pixels),
				errorMsg: "Incorrect output"
			}
		]
	}];

	// run tests
	runTests(tests);
}

function runTests(tests) {

	// run tests
	tests.forEach(test => {

		// print test message
		println(test.message.toUpperCase());
		println(" ");

		// run subtests for this test
		let failed = 0; // number of subtests failed

		for (let i = 0; i < test.subtests.length; i++) {

			let subtest = test.subtests[i];

			if (subtest.condition) {
				println("Check " + (i + 1) + " passed");
			} else {
				failed++;
				println("Check " + (i + 1) + " failed: " + subtest.errorMsg);
			}
		}
		println(" ");

		// all subtests passed
		if (failed === 0) {
			println("All checks passed.");
		} else {
			println(failed + " out of " + test.subtests.length + " checks failed.");
		}

		println("______________________________________________");

	});
}

// utility function to check if two arrays / objects are equal
function isEqual(a, b) {
	return objectHash.sha1(a) === objectHash.sha1(b);
}
