/**
 * global variables that will be assigned values in setup and used in draw
 */
var gImages = Array();
var gImage;
var gFeatureTracks;
var gCanvas;

function preload() {
	gImage = loadOpencvImage("1.jpg");
	for (let i = 1; i < 26; i++) {
		gImages.push(loadImage(i + ".jpg"));
	}
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	
	verifyInitializeTracks();
	verifyExtendTracks();
	verifyGetImageTracks();
	verifyRefocus();

	// convert images to opencv image type
	const opencvImages = Refocuser.getOpencvImages(gImages);
	// get features from images
	gFeatureTracks = Refocuser.getImageTracks(opencvImages);

	// draw all features
	const featurePoints = gFeatureTracks.getFeatures(0);
	for (let i = 0; i < featurePoints.length; i++) {
		cv.circle(gImage, featurePoints[i], 5, new cv.Scalar(0, 255, 0, 255), -1);
	}
	gCanvas = createOpencvCanvas(0, 0);
	cv.imshow(gCanvas, gImage);
}

/* refocuses the image and draws to canvas */
function drawImage(images, track) {
	// refocus image
	const output = Refocuser.refocus(images, track);
	image(output, gImage.cols, 0);

	// draw movement of a selected track
	let markedImage = new cv.Mat();
	gImage.copyTo(markedImage);
	for (let i = 0; i < track.length; i++) {
		cv.circle(markedImage, track[i], 5, new cv.Scalar(255, 0, 0, 255), -1);
	}
	cv.imshow(gCanvas, markedImage);

	//delete unused variables
	markedImage.delete();
}

/* handle mouse click event */
function mouseClicked() {
	let index = 0;
	let minDistance = Number.MAX_SAFE_INTEGER

	// find the feature closest to mouse pointer
	const features = gFeatureTracks.getFeatures(0);
	for (let j = 0; j < features.length; j++) {
		// sqrt is not required since the comparison is relative
		const distance = Math.pow(parseInt(features[j].y) - mouseY, 2) + Math.pow(parseInt(features[j].x) - mouseX, 2)
		// update if a shorter distance found
		if (distance < minDistance) {
			index = j;
			minDistance = distance;
		}
	}
	const track = gFeatureTracks.getTrack(index);
	// refocus and draw the image
	drawImage(gImages, track);
	// prevent default
	return false;
}