class Tracks {
	/* construct empty track instance */
	constructor() {
		this.data = Array();
	}

	/* add a track */
	addTrack(track) {
		this.data.push(track);
	}

	/* returns tracks ie: array of cv.points over time for a particular feature point */
	getTrack(index) {
		return this.data[index];
	}

	/* constructs a set of tracks from the points returned by good features to track, which is an Opencv matrix of size n*1 */
	static createFromGoodFeaturesToTrack(points) {
		const tracks = new Tracks();
		for (let i = 0; i < points.rows; i++) {
			const track = [];
			track.push(new cv.Point(points.data32F[i * 2], points.data32F[i * 2 + 1]))
			tracks.addTrack(track);
		}
		return tracks;
	}

	/*
	 * returns last track points as opencv matrix 
	 * return value points is an Opencv Mat, which can be passed directly to calcOpticalFlow Opencv method as prevPts
	 */
	getLastPoints() {
		const n = this.data.length;
		const lastIndex = this.data[0].length - 1;

		const points = new cv.Mat(n, 1, cv.CV_32FC2);
		for (let i = 0; i < n; i++) {
			const track = this.data[i];
			points.data32F[i * 2] = track[lastIndex].x;
			points.data32F[i * 2 + 1] = track[lastIndex].y;
		}
		return points;
	}

	/* constructs a set of tracks from another set of tracks and a set of points and status */
	createByExtendingTracks(points, status) {
		if(points.rows != this.getLastPoints().rows){
			throw Error("new points and old points (returned by getLastPoints) should have the same length");
		}
		const newTracks = new Tracks();
		const n = this.data.length;

		// keep valid tracks from the input - tracks
		for (let i = 0; i < n; i++) {
			if (status.data[i] === 1) {
				const track = this.getTrack(i);
				track.push(new cv.Point(points.data32F[i * 2], points.data32F[i * 2 + 1]))
				newTracks.addTrack(track);
			}
		}

		return newTracks;
	}

	/* take a track and return a tuple of deltaU and deltaV values. 
	/* Note that the track has continuous coordinates but here we return discrete coordinates using the u,v notation */
	static getDeltaTrack(track) {
		const deltaU = [];
		const deltaV = [];
		for (let i = 0; i < track.length; i++) {
			deltaU.push(parseInt(track[i].x) - parseInt(track[0].x));
			deltaV.push(parseInt(track[i].y) - parseInt(track[0].y));
		}
		return [deltaU, deltaV];
	}

	/* returns the first feature point of all the available tracks*/
	getFeatures(index) {
		const features = [];
		for (let i = 0; i < this.data.length; i++) {
			features.push(this.data[i][0]);
		}
		return features;
	}
}