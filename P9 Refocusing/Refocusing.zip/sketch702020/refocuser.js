class Refocuser {

	/* creates Opencv images out of p5.js image array and returns an javascript array of Opencv Mat type */
	static getOpencvImages(images) {
		const opencvImages = Array();
		const rows = images[0].height;
		const cols = images[0].width;

		// loop over image array and create Opencv images
		for (let i = 0; i < images.length; i++) {
			images[i].loadPixels();
			opencvImages.push(cv.matFromArray(rows, cols, cv.CV_8UC4, images[i].pixels));
		}
		return opencvImages;
	}

	/* initialize tracks with good features from the first image: cv.Mat(RGBA) and params: GftParams */
	static initializeTracks(image, params) {
		let grayscale = new cv.Mat();
		cv.cvtColor(image, grayscale, cv.COLOR_RGBA2GRAY);
		let tracks = new Tracks();
		let corners = new cv.Mat();
		
		cv.goodFeaturesToTrack(grayscale, corners,
													 params.maxCorners,
													 params.qualityLevel,
													 params.minDistance,
													 new cv.Mat(),
													 params.blockSize);
		return Tracks.createFromGoodFeaturesToTrack(corners);
	}

	/** 
	 * take a set a of tracks and possibly extend them yielding a new set of tracks
	 * takes oldImage: cv.Mat(RGBA), newImage: cv.Mat(RGBA), oldTracks: Tracks and params: KltParams as input
	 * output should be of type Tracks
	 */
	static extendTracks(oldImage, newImage, oldTracks, params) {
		let oldG = new cv.Mat();
		cv.cvtColor(oldImage, oldG, cv.COLOR_RGBA2GRAY);
		let newG = new cv.Mat();
		cv.cvtColor(newImage, newG, cv.COLOR_RGBA2GRAY);
		let points = new cv.Mat();
		let s = new cv.Mat();
		let e = new cv.Mat();
		cv.calcOpticalFlowPyrLK(oldG, newG, oldTracks.getLastPoints(),
													 points, s, e,
													 params.winSize,
													 params.maxLevel,
													 params.criteria);
		let newTracks = oldTracks.createByExtendingTracks(points, s);
		return newTracks;
	}

	/* takes a set of Opencv images and returns a Tracks instance */
	static getImageTracks(opencvImages) {
		let tracks = Refocuser.initializeTracks(opencvImages[0], new GftParams());
		for (let img = 0; img < opencvImages.length-1; img++) {
			tracks = Refocuser.extendTracks(opencvImages[img], opencvImages[img+1], tracks, new KltParams());
		}
		return tracks;
	}

	/* returns output image for a given set of images: Array(p5.js Image) and a track: Array(cv.Points) */
	static refocus(images, track) {
		let w = images[0].width;
		let h = images[0].height;
		let offset = Tracks.getDeltaTrack(track);
		let output = createImage(w, h);
		output.loadPixels();
		for (let y = 0; y < h; y++) {
			for (let x = 0; x < w; x++) {
				let index = 4* (x + y*w); 
				for (let img = 0; img < images.length; img++) {
					let tempX = x + offset[0][img];
					let tempY = y + offset[1][img];
					if (tempX >= 0 && tempY >= 0 && tempX < w && tempY <h) {
						let image = images[img];
						let tempIndex = 4 * (tempY * w + tempX);
						output.pixels[index]   += image.pixels[tempIndex]   / images.length;
						output.pixels[index+1] += image.pixels[tempIndex+1] / images.length;
						output.pixels[index+2] += image.pixels[tempIndex+2] / images.length;
						output.pixels[index+3] = 255;
					}
				}
			}
		}
		output.updatePixels();
		
		return output;
	}

}